package si.matjazcerkvenik.openmp3player.backend;

public enum OperatingSystem {
	
	OSX, LINUX, WINDOWS, OTHER
	
}
