#!/bin/bash

./server/apache-tomcat-7.0.57/bin/shutdown.sh

