#!/bin/bash

osascript -e "set Volume $1"
