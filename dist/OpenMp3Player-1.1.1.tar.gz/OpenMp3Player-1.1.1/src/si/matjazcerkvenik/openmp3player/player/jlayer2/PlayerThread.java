package si.matjazcerkvenik.openmp3player.player.jlayer2;

import si.matjazcerkvenik.openmp3player.player.jlayer.Pausable;

public class PlayerThread extends Thread {
	
	private Pausable player = null;
	
	@Override
	public void run() {
		
		
		
	}
	
}
