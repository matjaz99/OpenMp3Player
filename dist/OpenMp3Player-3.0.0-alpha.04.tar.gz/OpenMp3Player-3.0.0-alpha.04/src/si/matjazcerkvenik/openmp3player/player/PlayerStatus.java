package si.matjazcerkvenik.openmp3player.player;

public enum PlayerStatus {
	
	PLAYING, PAUSED, STOPPED, PLAY_ENDED
	
}
