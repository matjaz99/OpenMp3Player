#!/bin/bash

echo Starting OpenMp3Player...
./server/apache-tomcat-7.0.57/bin/startup.sh

