package si.matjazcerkvenik.openmp3player.web.comp;

import javax.faces.component.UIComponentBase;

public class MultiTagComponent extends UIComponentBase {

	@Override
	public String getFamily() {
		return "omp3p.multiTag";
	}

}
