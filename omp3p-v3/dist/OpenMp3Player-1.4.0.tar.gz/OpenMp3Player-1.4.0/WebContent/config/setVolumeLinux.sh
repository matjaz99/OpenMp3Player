#!/bin/bash

VOL="$1"0%
amixer set Master $VOL
