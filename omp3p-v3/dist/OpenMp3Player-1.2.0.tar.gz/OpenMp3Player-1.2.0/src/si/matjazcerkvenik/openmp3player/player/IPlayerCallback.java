package si.matjazcerkvenik.openmp3player.player;

public interface IPlayerCallback {
	
	public void playEnded();
	
}
